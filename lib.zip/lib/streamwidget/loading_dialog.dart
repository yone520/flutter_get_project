import 'dart:async';
import 'package:flutter/material.dart';
import 'package:abc/utils/size.dart';

typedef HideDialogCallBack = Future Function();

class LoadingDialog {
  static HideDialogCallBack showDialog(BuildContext context) {
    Completer completer = Completer();
    var result = OverlayEntry(
        builder: (context) {
          return Material(
            color: Colors.transparent,
            child: Center(
              child: Container(
                padding: EdgeInsets.all(Adapt.px(20)),
                color: Color.fromRGBO(0, 0, 0, 0.5),
                width: 100,
                height: 100,
                child: Center(
                  child: Image(
                    width: Adapt.px(150),
                    height: Adapt.px(150),
                    image: AssetImage('images/brown_horse.gif'),
                  ),
                ),
              ),
            ),
          );
        },
        maintainState: true);
    completer.complete(() {
      result.remove();
    });

    Overlay.of(context)!.insert(result);

    return () async {
      var hide = await completer.future;
      hide();
    };
  }
}
