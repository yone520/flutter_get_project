import 'dart:async';
import 'package:abc/streamwidget/GlobalState.dart';
import 'package:abc/streamwidget/multi_state.dart';

// 管理stream
class StateManager {
  late StreamController<GlobalState> streamController;

  StateManager() {
    streamController = StreamController();
  }

  void dispose() {
    streamController.close();
  }

  void loadingDialog() {
    streamController.sink.add(GlobalShowDialogState());
  }

  void loading() {
    streamController.sink.add(GlobalLoadingState());
  }

  void error() {
    streamController.sink.add(GlobalErrorState());
  }

  void content<T>(T t) {
    streamController.sink.add(GlobalContentState(t));
  }
}
