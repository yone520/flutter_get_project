import 'dart:async';

import 'package:flutter/material.dart';
import 'package:abc/streamwidget/GlobalState.dart';
import 'package:abc/streamwidget/StateManager.dart';
import 'package:abc/streamwidget/loading_dialog.dart';
import 'package:abc/utils/size.dart';

typedef GlobalContentBuilder<T> = Widget Function(
    BuildContext buildContext, T t);

class MultiStateWidget<T> extends StatefulWidget {
  Widget? loading = LoadingWidget();
  Widget? error = ErrorWidget();

  GlobalContentBuilder contentBuilder;

  StreamController<GlobalState> streamController;

  MultiStateWidget(
      {Key? key,
      required this.streamController,
      required this.contentBuilder,
      this.loading,
      this.error})
      : super(key: key);

  @override
  _MultiStateWidgetState<T> createState() => _MultiStateWidgetState<T>();
}

class _MultiStateWidgetState<T> extends State<MultiStateWidget> {
  HideDialogCallBack? hideDialogCallBack;

  // 记住上一个widget，避免出现空白的现象
  Widget? lastWidget;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: StreamBuilder<GlobalState>(
        stream: widget.streamController.stream,
        builder: (context, snap) {
          Widget result;

          if (snap.data != null) {
            if (snap.data is GlobalLoadingState) {
              result = LoadingWidget();
            } else if (snap.data is GlobalErrorState) {
              hideDialog();
              result = ErrorWidget();
            } else if (snap.data is GlobalShowDialogState) {
              Future.microtask(() {
                hideDialogCallBack = LoadingDialog.showDialog(context);
              });
              if (lastWidget != null) {
                result = lastWidget!;
              } else {
                result = Container();
              }
            } else if (snap.data is GlobalHideDialogState) {
              hideDialog();
              if (lastWidget != null) {
                result = lastWidget!;
              } else {
                result = Container();
              }
            } else if (snap.data is GlobalContentState) {
              hideDialog();
              result = widget.contentBuilder(
                  context, (snap.data as GlobalContentState).t);
            } else {
              result = Container();
            }
          } else {
            result = Container();
          }

          return lastWidget = result;
        },
      ),
    );
  }

  void hideDialog() {
    if (hideDialogCallBack != null) {
      hideDialogCallBack!();
      hideDialogCallBack = null;
    }
  }
}

// loading
class LoadingWidget extends StatelessWidget {
  const LoadingWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Image(
          width: 100,
          height: 100,
          image: AssetImage('images/loading.gif'),
        ),
      ),
    );
  }
}

// 错误
class ErrorWidget extends StatelessWidget {
  const ErrorWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Image(
          width: 100,
          height: 100,
          image: AssetImage('images/icon-no-message.png'),
        ),
      ),
    );
  }
}
