import 'package:shared_preferences/shared_preferences.dart';

class Global {
  static Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
  static late SharedPreferences prefs;
  static String initialRoute = '/';
  static Future init() async {
    prefs = await _prefs;
    var _profile = prefs.getString("profile");
    if (_profile != null) {

    }
  }
}
