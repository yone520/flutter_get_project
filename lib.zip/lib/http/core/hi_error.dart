// 错误类
class HiNetError implements Exception {
  final int code;
  final String message;
  final dynamic data;

  HiNetError(this.code, this.message, this.data);
}

// 需要登录的异常
class NeedLogin extends HiNetError {
  NeedLogin({int code: 401, String message: '请先登录', data})
      : super(code, message, data);
}

// 需要授权的异常
class NeedAuth extends HiNetError {
  NeedAuth({int code: 403, String message: "网络异常", data})
      : super(code, message, data);
}

// 404 异常
class NotFount extends HiNetError {
  NotFount({int code: 404, String message: "找不到页面", data})
      : super(code, message, data);
}

// 日期转换异常
class TimeFormat extends HiNetError {
  TimeFormat({int code: 50000, String message: "日期转换失败", data}): super(code, message, data);
}