import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:abc/http/core/hi_error.dart';
import 'package:abc/http/core/hi_net_adapter.dart';
import 'package:abc/http/request/base_request.dart';
import 'package:intl/intl.dart';

/// Dio 适配器
class DioAdapter extends HiNetAdapter {
  String getUTCDate(String time) {
    try {
      var f = DateFormat('E, dd MMM yyyy HH:mm:ss');
      var now = DateTime.parse(time).toUtc();
      return f.format(now) + ' GMT';
    } catch (e) {
      print('Error ******' + e.toString());
      throw e;
    }
  }

  @override
  Future<HiNetResponse<Object>> send<Object>(BaseRequest request) async {
    request.addHeader('Content-Type', 'application/x-www-form-urlencoded');

    // 添加 token
    print(
        '${request.header}-----------------------------------------------------end');
    var response, options = Options(headers: request.header);
    var error;
    try {
      if (request.httpMethod() == HttpMethod.GET) {
        if (request.params['st'] != null) {
          request.params['st'] = getUTCDate(request.params['st'] as String);
        }
        if (request.params['start_time'] != null) {
          request.params['start_time'] =
              getUTCDate(request.params['start_time'] as String);
        }
        if (request.params['et'] != null) {
          request.params['et'] = getUTCDate(request.params['et'] as String);
        }
        if (request.params['end_time'] != null) {
          request.params['end_time'] =
              getUTCDate(request.params['end_time'] as String);
        }
        response = await Dio().get(request.url(), options: options);
      } else if (request.httpMethod() == HttpMethod.POST) {
        response = await Dio()
            .post(request.url(), options: options, data: request.params);
        print("object: $response");
      }
    } on DioError catch (e) {
      Fluttertoast.showToast(
          msg: e.message,
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.black45,
          textColor: Colors.white,
          fontSize: 16.0);
      error = e;
      response = e.response;
    }
    if (error != null) {
      // 抛出 HiNetError
      throw HiNetError(response?.statusCode ?? -1, error.toString(),
          buildRes(response, request));
    }
    return buildRes(response, request) as HiNetResponse<Object>;
  }

  /// 构建 hiNetResponse
  HiNetResponse buildRes(Response response, BaseRequest request) {
    return HiNetResponse(
        data: response.data,
        request: request,
        statusCode: response.statusCode ?? 203,
        statusMessage: response.statusMessage ?? 'noMessage',
        extra: response);
  }
}
