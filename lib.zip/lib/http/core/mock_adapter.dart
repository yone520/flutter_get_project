// 测试适配器
import 'package:abc/http/core/hi_net_adapter.dart';
import 'package:abc/http/request/base_request.dart';

class MockAdapter extends HiNetAdapter {
  @override
  Future<HiNetResponse<Map>> send<Map>(BaseRequest request) {
    return Future<HiNetResponse<Map>>.delayed(Duration(milliseconds: 1000), () {
      return HiNetResponse<Map>(
          data: {"code": 0, "a": 1, "b": 2} as Map,
          request: request,
          statusCode: 403,
          statusMessage: "statusMessage");
    });
  }
}
