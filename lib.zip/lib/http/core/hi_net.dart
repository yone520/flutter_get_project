import 'dart:convert' as convert;
import 'package:abc/http/core/dio_adapter.dart';
import 'package:abc/http/core/hi_error.dart';
import 'package:abc/http/core/hi_net_adapter.dart';
import 'package:abc/http/request/base_request.dart';

class HiNet {
  HiNet._();

  static HiNet? _instance;

  static HiNet? getInstance() {
    if (_instance == null) {
      _instance = HiNet._();
    }
    return _instance;
  }

  // data 返回数据不定
  Map<String, dynamic> getDataMap<T>(T t) {
    Map<String, dynamic> decodedJSON;
    try {
      decodedJSON = convert.jsonDecode(t as String) as Map<String, dynamic>;
    } on FormatException catch (e) {
      decodedJSON = {"message": t};
      print('The provided string is not valid JSON');
    }
    return decodedJSON;
  }

  // 发送请求
  Future fire(BaseRequest request) async {
    HiNetResponse? response;
    var error;
    try {
      response = await send(request);
    } on HiNetError catch (e) {
      error = e;
      response = e.data;
      printLog(e.message);
    } catch (e) {
      // 其它异常
      error = e;
      printLog(2222);
      printLog(e);
    }

    if (response == null) {
      printLog(error);
      throw Error();
    }
    print("结果返回----");
    print(response);

    Map<String, dynamic> result = response.data is Map
        ? response.data
        : convert.jsonDecode(response.data);
    var status = response.statusCode;

    // 登录失效拦截
    if (result['data'] == 'token') {
      // 失效拦截，跳转登录
      return;
    }

    // 拦截错误
    if (result['status'] == false) {}
    switch (status) {
      case 200:
        print(200);
        // 如果status 为 false
        if (result["status"] == false) {
          throw (result['data']);
        } else {
          return result;
        }
      case 401:
        print(401);
        throw NeedLogin();
      case 403:
        print(403);
        throw NeedAuth(data: result);
      case 404:
        print(404);
        throw NotFount(data: result);
      default:
        throw HiNetError(status, result.toString(), result);
    }
  }

  Future<dynamic> send<T>(BaseRequest request) async {
    // printLog("url: ${request.url()}");
    // 使用 Mock 数据
    // printLog(request);
    // HiNetAdapter adapter = MockAdapter();
    // return adapter.send(request);
    // 使用 Dio 发送请求
    HiNetAdapter adapter = DioAdapter();
    return adapter.send(request);
  }

  void printLog(log) {
    print("hi_net：${log.toString()}");
  }
}
