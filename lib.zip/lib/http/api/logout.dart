import 'package:abc/http/request/base_request.dart';

class LogoutRequest extends BaseRequest {
  @override
  HttpMethod httpMethod() {
    return HttpMethod.GET;
  }

  @override
  bool needLogin() {
    return true;
  }

  @override
  String path() {
    return 'api/member/logout';
  }
}
