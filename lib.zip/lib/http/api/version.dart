import 'package:abc/http/request/base_request.dart';

class VersionRequest extends BaseRequest {
  @override
  HttpMethod httpMethod() {
    return HttpMethod.GET;
  }

  @override
  VersionRequest() {
    super.useHttps = true;
  }
  @override
  authority() {
    return 'ios.bmvip.win';
  }

  @override
  bool needLogin() {
    return false;
  }

  @override
  String path() {
    //1 android 2ios
    // appVersionCode
    // return 'https://ios.bmvip.win//iosign/release/version?appKey=cqr9yh&clientType=1&appVersionCode=1';
    return '//iosign/release/version';
    // return 'https://yq.kokvn10.com/iosign/release/version';
  }
}
