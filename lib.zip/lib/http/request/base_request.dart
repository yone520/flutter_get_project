
enum HttpMethod {
  GET,
  POST,
}

// 基础请求
abstract class BaseRequest {
  var pathParams;
  var useHttps = true; // 选择http协议
  String authority() {
    // return 'web.bmvip.win';
    // return '192.168.34.3:9081'; //开发环境
    return 'web.bmvip.win';
  }

  HttpMethod httpMethod();
  String path(); // 接口路由
  String url() {
    Uri uri;
    var pathStr = path();
    // 切换http和https
    var methods = httpMethod();
    if (useHttps) {
      if (methods == HttpMethod.GET) {
        uri = Uri.https(authority(), pathStr, params);
      } else {
        uri = Uri.https(authority(), pathStr);
      }
    } else {
      if (methods == HttpMethod.GET) {
        uri = Uri.http(authority(), pathStr, params);
      } else {
        uri = Uri.http(authority(), pathStr);
      }
    }
    if (needLogin()) {
      // addHeader('t', Global.profile.token);
    }
    return uri.toString();
  }

  // 接口是否需要登录
  bool needLogin();

  // 创建 params Map，用于参数
  Map<String, String> params = Map();
  BaseRequest add(String k, Object v) {
    params[k] = v.toString();
    return this;
  }

  // 添加header
  Map<String, dynamic> header = Map();
  BaseRequest addHeader(String k, Object v) {
    header[k] = v.toString();
    return this;
  }
}
