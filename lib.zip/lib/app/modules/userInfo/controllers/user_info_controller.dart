import 'package:get/get.dart';

class UserInfoController extends GetxController {
  //TODO: Implement UserInfoController
  final countaaa = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => {
    countaaa.value++,
  };
}
