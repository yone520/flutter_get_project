import 'package:get/get.dart';

import '../controllers/home_controller.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<HomeController>(
      // fenix: true 永久缓存
      // bindings 可以加载其它控制器
      () => HomeController(),
    );
  }
}
