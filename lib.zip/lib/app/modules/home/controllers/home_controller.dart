import 'package:get/get.dart';

class HomeController extends GetxController {
  //TODO: Implement HomeController

  final count = 0.obs;
  var name = "张三";

  @override
  void onInit() {
    super.onInit();
    print("begin...");
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;

  void changeName() {
    name = "王麻子";
    update(["Hal"]);
  }
}
