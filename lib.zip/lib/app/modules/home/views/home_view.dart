import 'package:abc/app/modules/login/controllers/login_controller.dart';
import 'package:abc/app/routes/app_pages.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:sp_util/sp_util.dart';

import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('HomeView'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Center(
            child: Text(
              controller.count.toString(),
              style: TextStyle(fontSize: 20),
            ),
          ),
          ElevatedButton(
              onPressed: () {
                Get.toNamed(Routes.LOGIN);
              },
              child: Text("login page")),
          GetBuilder<HomeController>(
              // 推荐使用 GetBuilder 更新数据，不建议使用.obs，性能问题
              id: "Hal",
              builder: (home) {
                return Text("用户A ${home.name}");
              }),
          GetBuilder<HomeController>(builder: (home) {
            return Text("用户B ${home.name}");
          }),
          ElevatedButton(
              onPressed: () {
                controller.changeName();
              },
              child: Text("改变name")),
          ElevatedButton(
              onPressed: () {
                Get.toNamed("/user-info");
              },
              child: Text("去用户详情")),

          ElevatedButton(
              onPressed: () async {
                await SpUtil.putString("token", "234243556856786");
              },
              child: Text("添加token")),

          ElevatedButton(
              onPressed: () async {
                await SpUtil.remove("token");
              },
              child: Text("删除token"))
        ],
      ),
    );
  }
}
