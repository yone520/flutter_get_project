import 'package:abc/app/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sp_util/sp_util.dart';

// 权限验证中间件
class AuthMiddleware extends GetMiddleware {
  @override
  int? priority = 2;

  @override
  RouteSettings? redirect(String? route) {
    String? token = SpUtil.getString("token");
    debugPrint('=======AuthMiddleware.redirect:$route');
    if (token == null || token == "") {
      // return RouteSettings(name: route);
      return RouteSettings(name: Routes.LOGIN);
    }
    return super.redirect(route);
  }

  @override
  GetPage? onPageCalled(GetPage? page) {
    debugPrint('=======AuthMiddleware.onPageCalled:$page');
    return super.onPageCalled(page);
  }
}
