import 'package:flutter/material.dart';

/// 去除回弹水波纹
class NoShadowScrollBehavior extends ScrollBehavior {
  final bool showLeading;
  final bool showTrailing;

  NoShadowScrollBehavior({this.showLeading = true, this.showTrailing = true});
  @override
  Widget buildViewportChrome(
      BuildContext context, Widget child, AxisDirection axisDirection) {
    switch (getPlatform(context)) {
      case TargetPlatform.iOS:
      case TargetPlatform.macOS:
        return child;
      case TargetPlatform.android:
      case TargetPlatform.fuchsia:
      case TargetPlatform.linux:
      case TargetPlatform.windows:
        return GlowingOverscrollIndicator(
          child: child,
          // 不显示头部水波纹
          showLeading: showLeading,
          //不显示尾部水波纹
          showTrailing: showTrailing,
          axisDirection: axisDirection,
          color: Colors.grey,
        );
    }
  }
}
