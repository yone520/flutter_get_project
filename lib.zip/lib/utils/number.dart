import "package:intl/intl.dart";

///数字转货币格式
String getFormatStepCountInt(dynamic number) {
  final format = NumberFormat("#,##0", 'zh_CN');
  if (number.toString() == '0') return '0';
  return format.format(number);
}

String getFormatStepCountFloat(dynamic number) {
  final format = NumberFormat("#,##0.00", 'zh_CN');
  if (number.toString() == '0') return '0.00';
  return format.format(number);
}
