import 'package:intl/intl.dart';

String formatDateTimeToUtc(DateTime time) {
  var f = DateFormat('E, dd MMM yyyy HH:mm:ss');
  var now = time.toUtc();
  return f.format(now) + ' GMT';
}
